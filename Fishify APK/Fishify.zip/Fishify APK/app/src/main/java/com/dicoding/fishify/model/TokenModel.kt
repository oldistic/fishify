package com.dicoding.fishify.model

data class TokenModel(
    val name: String,
    val token: String,
    val isLogin: Boolean
)