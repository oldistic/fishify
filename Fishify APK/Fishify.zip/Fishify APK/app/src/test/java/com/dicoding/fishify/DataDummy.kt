package com.dicoding.fishify

import com.dicoding.fishify.model.StoryResponseItem

object DataDummy {

    fun generateDummyStories() : List<StoryResponseItem> {
        val newList = ArrayList<StoryResponseItem>()
        for (i in 0..10) {
            val stories = StoryResponseItem(
                photoUrl = "photo_url ",
                name = "Story $i",
                description = "Description $i",
                lon = 1.0,
                id = "id $i",
                lat = 2.0
            )
            newList.add(stories)
        }
        return newList
    }
}